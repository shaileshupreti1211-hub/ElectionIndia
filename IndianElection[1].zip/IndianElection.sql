create database election;
use election;

CREATE TABLE states ( 
    state_id varchar(255) PRIMARY KEY, 
    state_name VARCHAR(255) NOT NULL 
); 
 
 
CREATE TABLE partywise_results ( 
    party_id INT PRIMARY KEY, 
    party_name VARCHAR(255) NOT NULL, 
    won INT NOT NULL 
); 
 
 
CREATE TABLE constituencywise_results ( 
    constituency_id VARCHAR(255) PRIMARY KEY, 
    parliament_constituency VARCHAR(255) NOT NULL, 
    constituency_name VARCHAR(255) NOT NULL, 
    winning_candidate VARCHAR(255) NOT NULL, 
    total_votes INT NOT NULL, 
    margin INT NOT NULL, 
    party_id INT, 
    FOREIGN KEY (party_id) REFERENCES 
partywise_results(party_id) 
); 
 
 
CREATE TABLE Candidates ( 
    candidate_id INT PRIMARY KEY AUTO_INCREMENT, 
    candidate_name VARCHAR(255) NOT NULL, 
    party_name VARCHAR(255) NOT NULL, 
    evm_votes INT NOT NULL, 
    postal_votes INT NOT NULL, 
    total_votes INT NOT NULL, 
    vote_percentage DECIMAL(5,2) NOT NULL, 
    constituency_id VARCHAR(255), 
    FOREIGN KEY (constituency_id) REFERENCES 
constituencywise_results(constituency_id) 
); 
 
 

CREATE TABLE statewise_results ( 
    statewise_id int PRIMARY KEY auto_increment, 
    constituency VARCHAR(255) NOT NULL, 
    constituency_no varchar(255) NOT NULL, 
    parliament_constituency VARCHAR(255) NOT NULL, 
    leading_candidate VARCHAR(255) NOT NULL, 
    trailing_candidate VARCHAR(255) NOT NULL, 
    margin int NOT NULL, 
    status VARCHAR(50) NOT NULL, 
    state_id varchar(255),
    state_name varchar(255),
    FOREIGN KEY (state_id) REFERENCES states(state_id) 
);


--  Find the party with the highest number of seats won.

select party_id, party_name, sum(won) as total_seats_won
from partywise_results
group by party_id
order by total_seats_won desc
limit 1;


--  Identify the candidate with the highest and lowest winning margin.

(select winning_candidate, constituency_name, margin  
 FROM constituencywise_results  
 ORDER BY margin DESC  
 LIMIT 1) 
UNION ALL 
(select winning_candidate, constituency_name, margin  
 FROM constituencywise_results  
 ORDER BY margin ASC  
 LIMIT 1);
 
 --  Calculate the total votes received by each party across all constituencies. 

select party_name, sum(total_votes) AS total_votes  
from Candidates  
group by party_name  
order by total_votes desc; 

--  Find the constituency with the smallest winning margin. 


select constituency_name, winning_candidate, margin
from constituencywise_results
order by margin asc
limit 1;

-- Determine the state with the highest and lowest voter turnout. 

(select s1.state_name,sum(c.total_votes) as voter_turnout
from statewise_results s
join constituencywise_results c
on s.constituency=c.constituency_name
join states s1
on s.state_id= s1.state_id
group by s1.state_id,s1.state_name
order by voter_turnout desc
limit 1)
union all
(select s1.state_name, sum(c.total_votes) as voter_turnout
from statewise_results s
join constituencywise_results c
on s.constituency=c.constituency_name
join states s1
on s.state_id= s1.state_id
group by s1.state_name
order by voter_turnout asc
limit 1);


--  Calculate the percentage of votes secured by the winning candidate in each constituency.

select constituency_name, winning_candidate, ( margin / total_votes) * 100 as Percentage
from constituencywise_results;

--  Find the number of constituencies where the winning candidate received more than 50% of total votes.

select count(*)  as Constituencies_Above_50_Percentage_Votes
from constituencywise_results
where (margin/total_votes)*100  > 50;

 --  Identify the party that secured the most runner-up positions.
 
 select p.party_id, p.party_name, count(s.trailing_candidate) as Most_Runner_ups
 from constituencywise_results c
 left join statewise_results s
 on c.constituency_name= s.constituency
 left join partywise_results p
 on c.party_id= p.party_id
 group by p.party_id, p.party_name
 order by count(s.trailing_candidate) desc
 limit 1;

-- Find the number of independent candidates who won and their constituencies.

select constituency_name, winning_candidate
from constituencywise_results
where party_id = 743
group by constituency_name, winning_candidate;


-- Calculate the average margin of victory across all constituencies.


select avg(margin) as average_victory_margin
from constituencywise_results;